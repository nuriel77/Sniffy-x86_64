# Sniffy HTTP Packet Inspection
__version__ = '1.0.1'
__author__  = 'Nuriel Shem-Tov, nurielst@hotmail.com'

